#LinkIt jQuery Plugin#

**LinkIt** is a simple jQuery plugin to attach links to elements

##Version##
0.2.0

##Usage##
    $('span').linkIt({
		href: 'http://test.com',
		text: 'Click Me',
		target: '_blank'
	});

##Vendors##
jQuery - [http://jquery.com](http://jquery.com)

##License##
MIT License